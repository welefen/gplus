# 1.4.1
1. 修复了顶部自定义添加的导航item不能active的bug（将class由icurrent_page_item改为current-menu-item）。 

# 1.4.2
1. 重新增加了jquery下点击链接页面跳到顶部的动画 
2. 修复了右侧最新评论点击后在新页面点击书签标题不正确的bug

# 1.4.3
1. 修复了调用widget方式在sinaapp下报错的bug

# 1.4.4
1. 给评论的用户名和邮箱添加了必填的*
2. 给评论的邮箱和URL增加了ime-mode:disabled
3. 优化了评论列表样式
4. 优化了详细页展现，去除了日期的突出显示

# 1.4.5
1. 增加了友情链接页面
2. 增加了日志归档页面