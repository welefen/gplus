
<form id="searchform" method="get" action="<?php echo home_url(); ?>/">

<input type="search" class="si" placeholder="<?php _e('Search: type', 'gplus'); ?>" size="35" maxlength="50" name="s" id="s" x-webkit-speech x-webkit-grammar="builtin:translate" />
</form>