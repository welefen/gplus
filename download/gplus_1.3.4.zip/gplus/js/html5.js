(function(){if(!
/*@cc_on!@*/
0){return}var e="abbr,article,summary,aside,datalist,details,dialog,eventsource,figure,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,time".split(","),i=e.length;while(i--){document.createElement(e[i])}})();